from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from backend.app.ml.anomaly_detector import AnomalyDetector

app = FastAPI(title="HACKVERSE MVP")

class Event(BaseModel):
    source: str
    timestamp: str
    ip: str
    user: str
    event_type: str
    features: dict

# simple in-memory detector instance
detector = AnomalyDetector()

@app.post('/api/v1/threats/detect')
async def detect(event: Event):
    features = list(event.features.values())
    try:
        score = detector.score([features])[0]
        is_anom = detector.is_anomaly(score)
        return {"is_threat": bool(is_anom), "score": float(score)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get('/')
async def root():
    return {"status": "ok"}
